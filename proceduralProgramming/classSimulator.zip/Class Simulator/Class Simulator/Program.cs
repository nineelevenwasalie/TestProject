﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace Class_Simulator
{
    class Program
    {
        static void Main(string[] args)
        {
            Random randInt = new Random();
            int knowledge = 50;
            Console.WriteLine("Welcome to Programming and Mobile Applications\n");
            Console.WriteLine("Please enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("\n What do you want to do? \n choose one of the following: \n Start Assignment \n Watch Youtube \n Talk with neighbor\n");
            string choice = Console.ReadLine();
            if (choice == "Start Assignment")
            {
                knowledge = knowledge + 2;
                Console.WriteLine("\n good job, " + name + " by starting you work right away you have increased you knowledge by 2, your knowledge is now: " + knowledge);
            }

            else if (choice == "Watch Youtube")
            {
                knowledge = knowledge - 25;
                Console.WriteLine("\n oh no your knowledge decreased by 25,  your knowledge is now: " + knowledge);
            }
            else if (choice == "Talk with neighbor")
            {
                Console.WriteLine("\n(yes/no) is the topic school realted? \n");
                string choice2 = Console.ReadLine();
                if (choice2 == "yes")
                {
                    knowledge = knowledge + 1;
                    Console.WriteLine("\n good job,  you have increased you knowledge by 1, your knowledge is now: " + knowledge);
                }
                else if (choice2 == "no")
                {
                    knowledge = knowledge - 10;
                    Console.WriteLine("\n oh no your knowledge decreased by 10,  your knowledge is now: " + knowledge);
                }
                else
                {
                    knowledge = knowledge - 1;
                    Console.WriteLine("\n that is not a valid command, please follow the directions \n oh no your knowledge decreased by 1,  your knowledge is now: " + knowledge);
                }
            }
            else
            {
                knowledge = knowledge - 1;
                Console.WriteLine("\n that is not a valid command, please follow the directions \n oh no your knowledge decreased by 1,  your knowledge is now: " + knowledge);
            }
            Console.WriteLine("\n (yes/no) Lecture starts do you want to pay attention?: ");
            choice = Console.ReadLine();
            if (choice == "yes")
            {
                int temp = randInt.Next(10, 20);
                knowledge = knowledge + temp;
                Console.WriteLine("\n good job,  you have increased you knowledge by " + temp + ", your knowledge is now: " + knowledge);
            }
            Console.WriteLine("\n (yes/no)You begin you assignment and you get stuck, ask for help?\n ");
            choice = Console.ReadLine();
            if (choice == "yes")
            {
                int temp = randInt.Next(10, 20);
                knowledge = knowledge + temp;
                Console.WriteLine("\n the teacher helps you and you understand what you were having difficulties with now,  you have increased you knowledge by " + temp + ", your knowledge is now: " + knowledge);
            }
            else if (choice == "no")
            {
                Console.WriteLine("\n (yes/no)do you look back over other problems or lecture notes, or ask Google for help?\n ");
                string choice2 = Console.ReadLine();
                if (choice2 == "yes")
                {
                    int temp = randInt.Next(10, 20);
                    knowledge = knowledge + temp;
                    Console.WriteLine("\n you find and example that you are able to work with to adapt to the problem you are trying to solve,  you have increased you knowledge by " + temp + ", your knowledge is now: " + knowledge);
                }
                else if (choice2 == "no")
                {
                    int temp = randInt.Next(1, 5);
                    knowledge = knowledge - temp;
                    Console.WriteLine("\n wasted time with out trying to solve, causes you to lose confidence and second guess your other work. \n  you have decreased you knowledge by " + temp + ", your knowledge is now: " + knowledge);
                }
                else
                {
                    knowledge = knowledge - 1;
                    Console.WriteLine("\n that is not a valid command, please follow the directions \n oh no your knowledge decreased by 1,  your knowledge is now: " + knowledge);
                }
            }
            else
            {
                knowledge = knowledge - 1;
                Console.WriteLine("\n that is not a valid command, please follow the directions \n oh no your knowledge decreased by 1,  your knowledge is now: " + knowledge);
            }
            Console.WriteLine("\n (yes/no)You finish you work early, do you want to do additional problems?\n ");
            choice = Console.ReadLine();
            if (choice == "yes")
            {
                int temp = randInt.Next(10, 20);
                knowledge = knowledge + temp;
                Console.WriteLine("\n The extra problems solidify the concepts and help prepare you for the test,  you have increased you knowledge by " + temp + ", your knowledge is now: " + knowledge);
            }
            else if (choice == "no")
            {
                Console.WriteLine("\n you did not take advantage of additional time to solidify the concepts learned so your knowledge did not increase");
            }
            else
            {
                knowledge = knowledge - 1;
                Console.WriteLine("\n that is not a valid command, please follow the directions \n oh no your knowledge decreased by 1,  your knowledge is now: " + knowledge);
            }
            Thread.Sleep(2000);
            Console.WriteLine("test time:  I hope you used your time wisely!");
            Console.WriteLine("press enter to take test");
            Console.ReadLine();
            Thread.Sleep(1000);
            Console.WriteLine("Taking test...");
            Thread.Sleep(3000);
            Console.WriteLine("test finished");
            Thread.Sleep(2000);
            int minNum = knowledge;
            int maxNum = knowledge + 10;
            if (minNum > 100)
            {
                minNum = 100;
            }
            if (maxNum > 100)
            {
                maxNum = 100;
            }
            int score = randInt.Next(minNum, maxNum);
            Console.WriteLine("looks like you got: " + score);
            if (score < 60)
            {
                Console.WriteLine("YOU FAILED!, you should have used your time better");
            }
            else if (score >= 90)
            {
                Console.WriteLine("Congrats" + name + " you got an A! you must have managed your time well!");
            }
            Console.ReadKey();
        }
    }
}
